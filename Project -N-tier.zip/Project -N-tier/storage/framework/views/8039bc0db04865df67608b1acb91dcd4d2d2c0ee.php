<?php $__env->startSection('title'); ?>
    Log In
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

   <form method="post" action="/logInme" class="login-box">
       <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="username" class="textbox">
       <br>
       <input type="password" name="password" placeholder="Password" class="textbox">
        <br>
       <input type="submit" name="submet" value="Login" class="btn">
   </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>