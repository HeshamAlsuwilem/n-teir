<?php $__env->startSection('title'); ?>
    Create
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <form method="POST" action="/project" class="login-box">
        <?php echo csrf_field(); ?>

        <h2 style="color: black">Name Of Project :
            <input type="text" name="name" class="textbox" placeholder="Enter Project Name">
        </h2>

        <h2 style="color: black">Duration :
            <input name="description" class="textbox" placeholder="Enter Project Duration">
        </h2>

        <input type="submit" name="AddPro" value="Add Project" class="bt1">
    </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>