<?php $__env->startSection('content'); ?>
    <div align="center">
        <br><br>
    <form method="" action="/afterupdateTask/<?php echo e($id); ?>" class="login-bo" >
    <?php echo csrf_field(); ?>
        <input name="name" type="text" class="textbox1" placeholder="New Task Name">
          <select name="state">
            <option value="New">New</option>
            <option value="In progress">In progress</option>
            <option value="Done">Done</option>
          </select>
        <br>
        <input type="submit" class="bt2" value="Update">
    </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>