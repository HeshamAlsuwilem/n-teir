<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
<style>
    #nav{
        list-style-type: none;
        padding: 0px;
        margin: 0px;
    }

    #nav li{
        display: inline-block;
        padding: 15px;
        margin: 0px;
        font-size: 19px;
        color: black;
    }

    #nav li:hover{
        background: #2397cF;
        transition: background 0.25s;
    }

    .login-box{
        width: 280px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%,-50%);
        color: white;
    }

    .textbox{
        width: 100%;
        overflow: hidden;
        font-size: 20px;
        padding: 8px 0;
        margin: 8px 0;
        border-bottom: 1px solid;
    }

    .textbox1{
        width: 50%;
        overflow: hidden;
        font-size: 20px;
        padding: 8px 0;
        margin: 8px 0;
        border-bottom: 1px solid;
    }

    .btn{
        width: 100%;
        background: none;
        border: 2px solid black;
        color: black;
        padding: 5px;
    }

.btn1{
        width: 50%;
        background: none;
        border: 2px solid black;
        color: black;
        padding: 5px;
    }
    body {
        font-family: "Roboto";
        font-size: 14px;
        background-size: 200% 100% !important;
        -webkit-animation: move 10s ease infinite;
        animation: move 10s ease infinite;
        -webkit-transform: translate3d(0, 0, 0);
        transform: translate3d(0, 0, 0);
        background: linear-gradient(45deg, #c3ffc8 10%, #7a95e5 90%);
        height: 100vh;
    }
    .bt2{
        display: inline-block;
        padding: 3px;
        margin: 0px;
        font-size: 10px;
        color: black;
        border: none;
        background: linear-gradient(45deg, #c3ffc8 10%, #7a95e5 90%);;
    }

    a{
        text-decoration: none;
        color: black;
    }
    a:hover{
        color: red;
    }
</style>

</head>
<body>
<ul id="nav" align="center">
<a href="/index"><li>Home</li></a>
<a href="/create"><li>Create</li></a>
<a href="/"><li>LogOut</li></a>
</ul>

<div align="center">
<?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html>