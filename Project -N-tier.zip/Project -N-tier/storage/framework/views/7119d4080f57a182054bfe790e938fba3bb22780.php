<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">List of Tasks</div>

                <div class="card-body">

                    <h1><?php echo e($project->name); ?></h1>
    <h3>Duration: <?php echo e($project->description); ?></h3>


<ul style="list-style-type:none">
    <?php $__currentLoopData = $project->Tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Tasks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li><h1>
        <div>
            <button> <?php echo e($Tasks->name); ?> </button>
            <button class="bt4"> <?php echo e($Tasks->state); ?> </button>
        </div> 
                <a href="/deleteTask/<?php echo e($Tasks->id); ?>"><button class="bt3">Delete</button></a>
                <a href="/updateTask/<?php echo e($Tasks->id); ?>"><button class="bt2">update</button></a></li>
            </h1>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


    <div align="center">
        <br><br>
    <form class="form" method="POST" action="/project/<?php echo e($project->id); ?>/task" class="login-box">

    <?php echo csrf_field(); ?>
        <input style="width:50%;" type="text" name="name" placeholder="Enter new task" class="textbox1"> <br>
        <input type="submit" name="AddTask" value="Add Task"class="bt1" >
    </form>
    </div>
                
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>