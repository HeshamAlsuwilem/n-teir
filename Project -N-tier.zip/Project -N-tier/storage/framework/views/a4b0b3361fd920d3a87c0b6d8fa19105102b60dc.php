<?php $__env->startSection('title'); ?>
    Welcome
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1><a href="/project/<?php echo e($projects->id); ?>"><?php echo e($projects->name); ?></a>
            <a href="/deleteProject/<?php echo e($projects->id); ?>"><button class="bt2">Delete</button></a>
            <a href="/updateProject/<?php echo e($projects->id); ?>"><button class="bt2">update</button></a></li>
        </h1>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>