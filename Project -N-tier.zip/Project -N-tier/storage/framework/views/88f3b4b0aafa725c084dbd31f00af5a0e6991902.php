<?php $__env->startSection('title'); ?>
    Create
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <form method="POST" action="/project" class="login-box">
        <?php echo csrf_field(); ?>

        <label style="color: black">Name Of Project :
            <input type="text" name="name" class="textbox" placeholder="Project Name">
        </label>

        <label style="color: black">Description :
            <textarea name="description" class="textbox" placeholder="Project description"></textarea>
        </label>

        <input type="submit" name="AddPro" value="Add Project" class="btn">
    </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>