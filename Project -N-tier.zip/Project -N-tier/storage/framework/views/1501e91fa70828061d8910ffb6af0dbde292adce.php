<?php $__env->startSection('title'); ?>
    update
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <form method="" action="/update/<?php echo e($id); ?>">
    <?php echo csrf_field(); ?>
        <input name="name" type="text" >
        <input type="submit">
    </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>