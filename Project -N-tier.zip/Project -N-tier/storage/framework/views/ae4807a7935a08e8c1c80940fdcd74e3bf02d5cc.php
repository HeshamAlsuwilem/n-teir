<?php $__env->startSection('title'); ?>
    <?php echo e($project->name); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <h1><?php echo e($project->name); ?></h1>
    <h3>Duration: <?php echo e($project->description); ?></h3>

    <hr>


<ul style="list-style-type:none">
    <?php $__currentLoopData = $project->Tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Tasks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <li><h1><?php echo e($Tasks->name); ?>

                <a href="/deleteTask/<?php echo e($Tasks->id); ?>"><button class="bt3">Delete</button></a>
                <a href="/updateTask/<?php echo e($Tasks->id); ?>"><button class="bt2">update</button></a></li>
            </h1>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<hr>
    <div align="center">
        <br><br>
    <form class="form" method="POST" action="/project/<?php echo e($project->id); ?>/task" class="login-box">

    <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="Enter new task" class="textbox1"> <br>
        <input type="submit" name="AddTask" value="Add Task"class="bt1" >
    </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>