<?php $__env->startSection('title'); ?>
    Welcome
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <h1><a href="/project/<?php echo e($projects->id); ?>"><button class="bt0"><?php echo e($projects->name); ?></button></a>
            <a href="/deleteProject/<?php echo e($projects->id); ?>"><button class="bt3">Delete</button></a>
            <a href="/updateProject/<?php echo e($projects->id); ?>"><button class="bt2">update</button></a></li>
        </h1>
            
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="/create"><button class="bt1">Add new project</button></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>